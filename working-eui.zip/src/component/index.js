export { EuiComponent } from "./component";
