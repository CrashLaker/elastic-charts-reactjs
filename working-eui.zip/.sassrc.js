const packageImporter = require("node-sass-package-importer");

module.exports = {
  importer: [packageImporter()]
};
